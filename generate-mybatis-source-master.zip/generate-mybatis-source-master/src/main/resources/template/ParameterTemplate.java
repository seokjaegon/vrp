package %packageName%.parameter;

import lombok.Getter;
import lombok.Setter;
[IMPORT]

@Setter
@Getter
public class %entityName%Param extends SearchParameter {
%classContents%
}
